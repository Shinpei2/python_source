# copy_password.py - パスワード管理プログラム
# モジュールのインポート
import pyperclip, sys

# 函数の定義
def copy_password(passwords):
    '''
    関数の説明： copy_password(passwords)
    ------------
        パスワードのデータからアカウント名を使って、
        パスワードをクリップボードにコピーする。
        アカウント名が指定されていない場合は、
        使い方を表示して終了する。

    Parameters
    ------------
        passwords（dict型）：アカウント名とパスワードの辞書データ 
    
    Returns
    ------------
        None:NoneType
    '''

    if len(sys.argv) == 1:
        print('アカウント名を指定してください。')
        print('使い方：python copy_passwaord.py [アカウント名]')
        sys.exit(1)
    
    account = sys.argv[1]

    if account in passwords:
        pyperclip.copy(passwords[account])
        print(account + 'のパスワードをクリップボードにコピーしました')
    else:
        print('アカウントが見つかりませんでした。')
        sys.exit(2)
        

# テストコード
if __name__ == "__main__":

    # 変数の定義
    dict_passwords = {
      'mki_user': 'F7minlBDDuvMJuxESSKHFhTxFtjVB6',
      'azure_user': 'VmALvQyKAxiVH5G8v01if1MLZF3sdt',
      'devops_user': '12345'
    }

    # 函数やクラスのプログラム実行
    copy_password(dict_passwords)


