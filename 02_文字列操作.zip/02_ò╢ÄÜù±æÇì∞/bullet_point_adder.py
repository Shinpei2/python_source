# モジュールのインポート
import pyperclip

# 函数の定義
def bullet_point_adder():
    """
    函数の説明
    bullet_point_adder()

    クリップボードにコピーした行データの先頭に*（アスタリスク）を結合する。
    mojimoji
    ↓
    * mojimoji
    結果をクリップボードにコピーする。
    その後、結果をターミナルに表示する。

    Parameters
    ------
        None

    Returns
    ------
        None : NoneType
    """
    # 改行コードを定義
    cr_lf_code = "\r\n"     # VSの改行コードは、Unixと異なるので注意する
    
    # クリップボードからテキストを取得する
    text = pyperclip.paste()

    # 行を改行で分割する
    lines = text.split(cr_lf_code)

    # "lines"リストの各要素を要素数分ループする
    for i in range(len(lines)):
        # "lines"の要素の先頭に"* "を結合する
        lines[i] = '* ' + lines[i]

    # リストを改行の文字コードで結合する
    bullet_point_added_text = cr_lf_code.join(lines)

    # 新しいテキストをクリップボードにコピーする
    pyperclip.copy(bullet_point_added_text)
    
    # 結果を表示する
    print("bullet point added")
    print(bullet_point_added_text)


# テストコード
if __name__ == "__main__":
    # 函数やクラスのプログラム実行
    bullet_point_adder()
