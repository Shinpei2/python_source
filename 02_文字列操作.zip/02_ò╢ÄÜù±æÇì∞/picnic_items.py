# モジュール、パッケージのimport
# 並び順
# 1.Python標準モジュール
# 2.外部モジュール、パッケージ
# 3.自作モジュール、パッケージ


# 変数の定義（函数などで使用するもの）

# 函数の定義
def print_picnic(items_dict, left_width, right_width):
    '''
    関数の説明
    ------------
        辞書内のデータを表形式で表示する関数

    Parameters
    ------------
        items_dict(dict型) : 持ち物辞書データ
        left_width（int型） : キーの表示幅
        right_width : int  : 値の表示幅

    Returns
    ------------
        None:NoneType
    '''
    print('PICNIC ITEMS'.center(left_width + right_width, '-'))
    for k, v in items_dict.items():
        print(k.ljust(left_width, '.') + str(v).rjust(right_width))


# テストコード
if __name__ == "__main__":
    # 変数の定義
    picnic_items = {'sandwiches': 4, 'apples': 12, 'cups': 4, 'cookies': 8000}

    # 函数やクラスのプログラム実行
    print_picnic(picnic_items, 20, 6)