def hiyake(person):
    hiyake = person + '(真っ黒)'
    print(hiyake)


if __name__ == "__main__":
    hito = 'kuroiwa'
    hiyake(hito)
    # print(hito2)
    # print(hito)