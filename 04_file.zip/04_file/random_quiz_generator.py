import os, random

def capitals_quiz(capitals_dict, how_many_kinds):
    '''
    関数の説明：県庁所在地クイズを作成する
    -----------

    Parameters
    -----------
        capitals_dict(dict型) :都道府県と県庁所在地の辞書データ
        how_many_kinds(int型) : 問題と解答集が幾通りか   
    Retruns
    -----------
        None:NoneType
    '''
    # TODO: パスを文字列に格納
    p_folder =  'capitalsquiz'
    a_folder =  'capitalsquiz_answers'
    problems_dir = os.path.join(os.getcwd(), p_folder)
    answers_dir = os.path.join(os.getcwd(), a_folder)
    

    # ファイルのナンバーが1から始まるようにする
    # 1からhow_many_kinds分繰り返して問題と解答を作成する
    for quiz_num in range(how_many_kinds):
        # 問題集ファイルを書き込みモードで開く
        quiz_file = open(os.path.join(problems_dir, 'capitalsquiz{}.txt'.format(quiz_num + 1)), mode='w', encoding='utf-8')
        # TODO : 解答集ファイルを書き込みモードで開く
        answer_key_file = open(os.path.join(answers_dir, 'capitalsquiz_answers{}.txt'.format(quiz_num+1)), mode='w', encoding='utf-8')

        # 問題のヘッダを書く
        # TODO : 「名前:」と「日付:」を書き込む
        quiz_file.write('名前:\n\n')
        quiz_file.write('日付:\n\n')
        quiz_file.write((' ' * 20) + '都道府県庁所在地クイズ (問題番号 {})'.format(quiz_num + 1))
        quiz_file.write('\n\n')

        
        # TODO : 都道府県（キー）をリストで格納する
        prefectures = []
        for k in capitals_dict.keys():
            prefectures.append(k)
        # prefectures = [k for k in capitals_dict.keys()]

        # 都道府県の順番をシャッフルする
        random.shuffle(prefectures)

        # 47都道府県をループして、それぞれの問題集を作成する
        for question_num in range(len(prefectures)):
            # 正解を取得する
            # TODO : 都道府県（キー）で県庁所在地（値）を取得する
            correct_answer = capitals_dict[prefectures[question_num]]  # [] :
            
            # 誤答を作成する
            # TODO : capitals_dictのすべての県庁所在地（値）をリスト型で複製する
            wrong_answers = list(capitals_dict.values())

            # wrong_answersから正解を削除する
            # TODO : # wrong_ansewersの中で、correct_answerが含まれるインデックスを取得し、正解を削除
            del wrong_answers[wrong_answers.index(correct_answer)]

            # random.sample()でランダムに3つ選ぶ
            wrong_answers = random.sample(wrong_answers, 3)

            # TODO : 3つの誤答（wrong_answers）と正解（correct_answer）をまとめて選択肢リストとする
            answer_options = wrong_answers + [correct_answer]

            # 選択しリストをシャッフルする
            random.shuffle(answer_options)

            # TODO: 問題文と回答選択肢を問題ファイルに書く
            quiz_file.write('{}. {}の都道府県庁所在地は?\n'.format(question_num + 1, prefectures[question_num]))

            # answer_optionsリストの選択肢を0～3まで順番に表示
            choice = 'ABCD'
            for i in range(4):
                # answer_optionsから選択肢を順番に取得する
                quiz_file.write(' {}. {}\n'.format(choice[i], answer_options[i]))
            quiz_file.write('\n')

            # TODO: 答えの選択肢をファイルに書く
            # correct_answerのアルファベットを表示
            answer_key_file.write('{}. {}\n'.format(question_num + 1, choice[answer_options.index(correct_answer)]))

        # TODO : 問題集ファイルをクローズ
        quiz_file.close()
        # TODO : 解答集ファイルをクローズ
        answer_key_file.close()
      


# テストコード
if __name__ == "__main__":
    test_num = 6

    # 問題のデータ。キーが都道府県で、値が県庁所在地
    capitals = {'北海道': '札幌市', '青森県': '青森市', '岩手県': '盛岡市', 
        '宮城県': '仙台市', '秋田県': '秋田市', '山形県': '山形市', '福島県': '福島市',
        '茨城県': '水戸市', '栃木県': '宇都宮市', '群馬県': '前橋市',
        '埼玉県': 'さいたま市', '千葉県': '千葉市', '東京都': '東京',
        '神奈川県': '横浜市', '新潟県': '新潟市', '富山県': '富山市', '石川県': '金沢市',
        '福井県': '福井市', '山梨県': '甲府市', '長野県': '長野市', '岐阜県': '岐阜市',
        '静岡県': '静岡市', '愛知県': '名古屋市', '三重県': '津市', '滋賀県': '大津市',
        '京都府': '京都市', '大阪府': '大阪市', '兵庫県': '神戸市', '奈良県': '奈良市',
        '和歌山県': '和歌山市', '鳥取県': '鳥取市', '島根県': '松江市',
        '岡山県': '岡山市', '広島県': '広島市', '山口県': '山口市', '徳島県': '徳島市',
        '香川県': '高松市', '愛媛県': '松山市', '高知県': '高知市', '福岡県': '福岡市',
        '佐賀県': '佐賀市', '長崎県': '長崎市', '熊本県': '熊本市', '大分県': '大分市',
        '宮崎県': '宮崎市', '鹿児島県': '鹿児島市', '沖縄県': '那覇市'}
    
    # CDを04_fileフォルダに指定
    os.chdir(r'04_file')

    # TODO: 問題集と解答集を格納するフォルダの作成
    p_folder =  'capitalsquiz'
    a_folder =  'capitalsquiz_answers'
    problems_dir = os.path.join(os.getcwd(), p_folder)
    answers_dir = os.path.join(os.getcwd(), a_folder)

    # 問題集フォルダの作成
    if not (os.path.isdir(problems_dir)):
        os.mkdir(p_folder)
    
    # 解答集フォルダの作成
    if not (os.path.isdir(answers_dir)):
        os.mkdir(a_folder)

    # 問題集作成の関数を実行
    capitals_quiz(capitals, test_num)