import json
import requests
import sys
import os

def get_weather_info(location, api_key):
    '''
    関数の説明：OpenWeatherMapのAPIを利用して、天気情報のJSONデータを取得し、必要な情報を取り出す
    -----------

    Parameters
    -----------
        location(str型)：都道府県名  
        api_key(str型)：OpenWeatherMapのAPI key
    Retruns
    -----------
        None:NoneType
    '''

    # TODO: JSONデータのダウンロード
    # APIが渡されていなければメッセージを返す
    # assert 条件式, 条件式がFalseの場合に出力するメッセージ
    assert api_key != '', 'API keyを定義してください。'

    # OpenWeatherMap.orgのAPIからJSONデータをダウンロードする
    url = "http://api.openweathermap.org/data/2.5/forecast?q={location}&mode=json&appid={api_key}"
    api_url = url.format(location = location, api_key = api_key)

    # MKI-LANの場合はプロキシの設定
    os.environ['HTTP_PROXY'] = "http://150.67.140.80:3128"

    response = requests.get(api_url)

    # HTTPのステータスコードを調べる
    # print(response.status_code)

    # HTTPステータスが200以外の場合、例外を発生
    response.raise_for_status()

    # TODO: JSONデータを読み込み天気予報を表示
    # JSON形式の文字列を、Pythonの辞書として読み込み
    weather_data = json.loads(response.text)
    # 天気予報の情報を表示
    w = weather_data['list']
    print('{}の現在の天気:'.format(location))
    for i in range(len(w)):
        print(w[i]['weather'][0]['main'], '-', w[i]['weather'][0]['description'])
        print()
        if i < len(w)-1:
            print("{}日後の天気:".format(i+1))
    
    # print('{}の現在の天気:'.format(location))
    # print(w[0]['weather'][0]['main'], '-', w[0]['weather'][0]['description'])
    # print()
    # print('明日:')
    # print(w[1]['weather'][0]['main'], '-', w[1]['weather'][0]['description'])
    # print()
    # print('明後日:')
    # print(w[2]['weather'][0]['main'], '-', w[2]['weather'][0]['description'])


if __name__ == "__main__":
    # 都道府県名
    my_location = "Tokyo"

    # OpenWeatherMapから取得したAPI key
    my_api_key = "9bbc88188961a4408c2afbb107640830"  # 正しいAPI Key : 9bbc88188961a4408c2afbb107640830

    # get_weather_infoの実行
    get_weather_info(my_location, my_api_key)
