def display_items(dict_items):
    # アイテム総数を計算するための変数
    item_total = 0
    print('持ち物リスト：')
    for k,v in dict_items.items():
        print(v, k)
        item_total += v     # item_total = item_total + v
    print('アイテム総数：', item_total)


# setdefaultを使うパターン ※参照引き渡し
def add_to_player_items(dict_items, add_items):
    # add_itemsから1つずつ取り出して操作する
    for add_item in add_items:
        dict_items.setdefault(add_item, 0)   # キーが存在しない場合のみ、デフォルト値を0に設定　※（）内：（key, value）
        dict_items[add_item] += 1           # 追加されたアイテムの辞書の値をプラス1する。
    return dict_items


# setdefaultを使わないパターン
# def add_to_player_items(dict_items, add_items):
#     for add_item in add_items:
#         # キーが存在しない場、新たにキーをセット
#         if add_item not in dict_items:
#             dict_items[add_item] = 0
#         dict_items[add_item] += 1    # 追加されたアイテムの辞書の値をプラス1する。
#     return dict_items


# テスト
if __name__ == "__main__":
    # プレーヤーの持ち物リストを辞書型にモデル化
    player_items = {
        'ロープ': 1, 'たいまつ': 6, '金貨': 42, 
        '手裏剣': 1, '矢': 12
    }
    display_items(player_items)


    # ドラゴンに勝って獲得したアイテムのリスト
    dragon_items = ['金貨', '手裏剣','金貨', '金貨', 'ルビー']
    ans = add_to_player_items(player_items, dragon_items)  # ※参照引き渡し（identityを渡す）

    print()
    display_items(ans)



