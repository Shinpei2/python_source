# クラス定義
class StarDust():
    # クラス変数
    count = 0
    office = 'スターダスト'

    # 初期化メソッド
    def __init__(self, name):
        self.name = name
        self.__class__.count += 1

    # インスタンスメソッド
    def set_id(self, id):
        self.id = id

    def set_number(self, number):
        self.number = number
    
    def set_introduce(self, introduce):
        self.introduce = introduce
    
    def display_table(self):
        print('------------------------')
        print(self.name, self.id, self.number, self.introduce)
        print('------------------------')
    # クラスメソッド
    def get_count(cls):
        print(cls.count)

# 
if __name__ == "__main__":
    okada = StarDust('岡田')
    print(okada.name)
    print(okada.__class__.office)

    okada.set_id(123)
    okada.set_number(1)
    okada.set_introduce('岡田将生です')
    okada.display_table()


