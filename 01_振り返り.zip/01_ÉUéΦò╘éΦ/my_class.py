from my_functions import check_for_multiples

# クラス定義
class MyClass():
    # クラス変数
    count = 0
    classname = 'MyClass'

    # 初期化メソッド
    def __init__(self, name):
        self.name = name
        self.__class__.count += 1

    # インスタンスメソッド
    def set_id(self, id):
        self.id = id
    def set_department(self, department):
        self.department = department
    def set_introduce(self, introduce):
        self.introduce = introduce
    def display_classname(self):
        print("クラス名は、", self.__class__.classname, "です。")
    def display_table(self):
        print('------------------------')
        print(str(self.id) + ', ' + self.name + ', ' + self.department + ', ' + self.introduce)
        print('------------------------')

    # クラスメソッド
    def get_count(cls):
        print(cls.count)


if __name__ == "__main__":
    c1 = MyClass('arinaga')
    print(c1.name)
    c1.set_id('95027')
    c1.set_department('IIS-T2') 
    c1.set_introduce('takumi')
    c1.display_classname()
    c1.display_table()
    print(MyClass.count)
