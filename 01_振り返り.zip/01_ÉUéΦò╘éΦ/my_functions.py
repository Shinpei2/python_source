def check_for_multiples(number):

    if number % 15 == 0:
        return '{}は、3と5で割り切れます。'.format(number)
    elif number % 5 == 0:
        return '{}は、5で割り切れます。'.format(number)
    elif number % 3 == 0:
        return '{}は、3で割り切れます。'.format(number)
    else:
        return str(number)


# print(__name__)     # 自分のファイル名を表示

if __name__ == "__main__":
    for i in range(1, 31):
        string = check_for_multiples(i)
        print(string)


