# モジュール、パッケージのimport
# 並び順
# 1.Python標準モジュール
# 2.外部モジュール、パッケージ
# 3.自作モジュール、パッケージ


# 函数の定義
def to_add(a, b):
    c = 0
    c = a + b
    return c

# テストコード
if __name__ == "__main__":
    num1 = 10
    num2 = 20
    sum = 0
    sum = to_add(num1 , num2)

    print(sum)