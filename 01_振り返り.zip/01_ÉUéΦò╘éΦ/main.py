from my_functions import check_for_multiples
import my_class

for i in range(1, 31):
    print(check_for_multiples(i))


# my_class.py内で定義したクラスのインスタンスを生成
c1 = my_class.MyClass('class1')
# インスタンスメソッドの呼び出し
c1.set_id(1)
c1.set_department('dorei')
c1.set_introduce('I am slave.')
c1.display_table()
# クラスメソッドの呼び出し
c1.get_count()