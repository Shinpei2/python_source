# モジュール

# 変数の定義

# 関数の定義
# display_key() : 辞書キーを全て表示する関数
def display_key(dict_month):
    keys_list = []
    # dictからキーを順に取り出してkeysに追加する。
    for key in dict_month:
        # print(f"{key}")
        keys_list.append(key)

    # 結果を表示
    print("辞書データのキー：")
    print(keys_list)

# display_value() : 辞書の値を全て表示する関数
def display_value(dict_month):
    values_list = []
    # dictから値を順に取り出してvaluesに追加する。
    for value in dict_month.values():
        # print(value)
        values_list.append(value)
    
    # 結果を表示
    print("辞書データの値：")
    print(values_list)


# display_dic() : 辞書のキーと値の組み合わせを表示する関数
def display_dic(dict_month):
    print("辞書のキーと値の組み合わせ：")
    for k,v in dict_month.items():
        print(k + 'は、' + str(v) + '月です。' )
        



if __name__ == "__main__":
    monthNumbers = {
        'Jan': 1, 'Feb': 2, 
        'Mar': 3, 'Apr': 4, 
        'May': 5, 'Jun': 6,
        'Jul': 7, 'Aug': 8, 
        'Sep': 9, 'Oct': 10, 
        'Nov': 11, 'Dec': 12
    }

    
    # 各関数の呼び出し
    display_key(monthNumbers)
    display_value(monthNumbers)
    display_dic(monthNumbers)

