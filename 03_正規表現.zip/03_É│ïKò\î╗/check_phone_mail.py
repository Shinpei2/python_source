# モジュールのインポート
import re, pyperclip


def get_phone_and_email(phone_regex, email_regex):
    '''
    関数の説明：クリップボードから、電話番号と電子メールアドレスを抽出し、
    抽出したものをクリップボードにコピーする。
    -----------

    Parameters
    -----------
        phone_regex(str型)：電話番号を表す正規表現の文字列
        email_regex(str型)：メールアドレスを表す正規表現の文字列
    
    Retruns
    -----------
        None:NoneType
    '''

    # 改行コードを定義
    cr_lf_code = "\r\n"

    # TODO: 電話番号の正規表現のコンパイル。
    phone_obj = re.compile(phone_regex)

    # TODO: 電子メールの正規表現のコンパイル。
    email_obj = re.compile(email_regex)

    # TODO: クリップボードのテキストを取得。
    text = pyperclip.paste()

    # TODO: クリップボードのテキスト（電話番号、電子メール）を検索する。
    phone_list = phone_obj.findall(text)
    email_list = email_obj.findall(text)

    # TODO: 電話番号とメールアドレスをjoinして1つの文字列に変換する
    paste_list = []

    # paste_listに、電話番号を追加する
    for item in phone_list:
        paste_list.append(item)
    # paste_listに、メールアドレスを追加する
    for item in email_list:
        paste_list.append(item)
    # リストを改行の文字コードで結合する
    phone_email_texts = cr_lf_code.join(paste_list)

    # TODO: 検索結果をクリップボードに貼り付ける。
    pyperclip.copy(phone_email_texts)
    print('電話番号とメールアドレスをクリップボードに貼り付けました！')


if __name__ == "__main__":
    phone_reg = r"\d{3}-\d{4}-\d{4}"
    email_reg = r"([\w_-]+@\w+\.co\.jp)"

    # emaiL_reg = r"ユーザー名@ドメイン名.co.jp"
    reg = re.compile(r"[\w_-]+@[\w]+[.]co[.]jp")

    # mo = reg.search("akdaoidf_-a@aa9a.co.jp")
    # print(mo.group())

    # 関数get_phone_and_email()の実行
    get_phone_and_email(phone_reg, email_reg)