
def is_phone_number(text):
    # ①文字列長が13文字かどうか
    if len(text) != 13:
        # 文字列長が13文字ではない場合
        return False
    # ②市外局番（3桁）のチェック
    for i in range(0, 3):
        # 市外局番が数字だけで構成されているか
        if not text[i].isdecimal():
            # 市外局番が数字だけで構成されていない場合
            return False
    # ③市外局番の後がハイフンかどうか
    if text[3] != '-':
        # 市外局番の後がハイフンではない場合
        return False
    # ④市内局番（4桁）のチェック
    for i in range(4, 8):
        # 市内局番が数字だけで構成されているか
        if not text[i].isdecimal():
            # 市内局番が数字だけで構成されていない場合
            return False
    # ⑤ハイフンが続くこと
    if text[8] != '-':
        return False
    # ⑥加入者番号（4桁）のチェック
    for i in range(9, 13):
        # 加入者番号が数字だけで構成されているか
        if not text[i].isdecimal():
            # 加入者番号が数字だけで構成されていない場合
            return False
    # ⑦全て一致すればTrueを返す
    return True

def search_phone_number(message):
    for i in range(len(message)):
        # ①12文字のまとまりで文字列を切り出す
        chunk = message[i: i+13]
        # ②電話番号のパターンに一致するか調べる
        if is_phone_number(chunk):
            # パターンが一致した場合は電話番号を表示する
            print('電話番号が見つかりました: ' + chunk)

# テストコード
if __name__ == "__main__":

    # if is_phone_number(input('電話番号を入力してください>>> ')):
    #     print('電話番号')
    # else:
    #     print('not電話番号')
    
    search_phone_number(input('電話番号を入力してください>>> '))
    
