import re

def regex_match(text, regex_text):
    '''
    関数の説明：文字列の先頭で正規表現とマッチするか判定
    -----------

    Parameters
    -----------
        text(str型)：電話番号を表す文字列
        regax_text(str型)：正規表現の文字列
    
    Retruns
    -----------
        None:NoneType
    '''
    # regaxオブジェクトの生成
    regex_obj = re.compile(regex_text)

    # match()メソッドを使って判定する
    match_obj = regex_obj.match(text)
    # print("Match object:", match_obj)

    # 表示
    if match_obj is not None:
        print('マッチした文字列：', match_obj.group())
        print('マッチした文字列の開始位置：', match_obj.start())
        print('マッチした文字列の終了位置：', match_obj.end())
        print('マッチした文字列の(開始, 終了)位置：', match_obj.span())
    else:
        print('文字列の先頭で正規表現とマッチしませんでした。')


def regex_search(text, regex_text):
    '''
    関数の説明：文字列の中にパターンとマッチする部分があるかどうかを判定
    -----------

    Parameters
    -----------
        text(str型)：電話番号を表す文字列
        regax_text(str型)：正規表現の文字列
    
    Retruns
    -----------
        None:NoneType
    '''
    # Regaxオブジェクト生成
    regex_obj = re.compile(regex_text)

    # search()メソッドを用いて、Matchオブジェクトを生成
    match_obj = regex_obj.search(text)
    print('Match object:', match_obj)
    
    # 表示
    if match_obj is not None:
        print('電話番号が見つかりました：', match_obj.group())
    else:
        print('電話番号が見つかりませんでした。')


def regex_findall(text, regex_text):
    '''
    関数の説明：正規表現にマッチする部分を全て探し出し、リストとして返す
    -----------

    Parameters
    -----------
        text(str型)：電話番号を表す文字列
        regax_text(str型)：正規表現の文字列
    
    Retruns
    -----------
        None:NoneType
    '''

    # Regexオブジェクトの生成
    regex_obj = re.compile(regex_text)
    # findall()メソッドを使って、リストを作成する
    match_obj = regex_obj.findall(text)
    # print('Match object:', match_obj)

    # Matchオブジェクト(リスト)から情報を取り出して表示
    # リストの要素数が1以上の場合に表示
    if len(match_obj) >= 1:
        print('マッチした文字列：')
        for i in range(len(match_obj)):
            print(match_obj[i])
    else:
        print('電話番号が見つかりませんでした。')

def regex_finditer(text, regex_text):
    '''
    関数の説明：正規表現にマッチする部分文字列を全て探し出し、iteoratorとして返す
    -----------

    Parameters
    -----------
        text(str型)：電話番号を表す文字列
        regax_text(str型)：正規表現の文字列
    
    Retruns
    -----------
        None:NoneType
    '''
    # Regexオブジェクトを生成（正規表現をコンパイル）
    regex_obj = re.compile(regex_text)

    # finditer()メソッドを使って判定する
    match_obj = regex_obj.finditer(text)


    # 内容の確認
    # print("Match object:", match_obj)
    
    # 表示
    length = len(list(match_obj))       # list(イテレーター)を記述すると、イテレーターが初期化される
    if length >= 1:
        match_obj = regex_obj.finditer(text)        # 初期化されたmatch_objに再度iteratorオブジェクトを代入
        print('---------------------------------------')
        for item in match_obj:
            print('マッチした文字列：', item.group())
            print('マッチした文字列の開始位置：', item.start())
            print('マッチした文字列の終了位置：', item.end())
            print('マッチした文字列の(開始, 終了)位置：', item.span())
            print('---------------------------------------')
    else:
        print('正規表現とマッチしませんでした。')
    


# テストコード
if __name__ == "__main__":
    target_reg = r'\d{3}-\d{4}-\d{4}'
    
    # target_text = '明日003-5353-1011に電話してください。オフィスは003-5353-9999です'
    # target_text ='明日09-3311'
    target_text = '003-5353-1011に電話してください。オフィスは003-5353-9999です'


    # matchメソッドの関数の実行
    # regex_match(target_text, target_reg)

    # searchメソッドの関数の実行
    # regex_search(target_text, target_reg)

    # findallメソッドの関数の実行
    # regex_findall(target_text, target_reg)

    # finditerメソッドの関数の実行
    regex_finditer(target_text, target_reg)




