import re

def basic_is_phone_number(text, regex_text):
    '''
    関数の説明：テキスト内の電話番号を正規表現を用いて探索する
    -----------

    Parameters
    -----------
        text(str型)：電話番号を表す文字列
        regax_text(str型)：正規表現の文字列
    
    Retruns
    -----------
        None:NoneType
    '''

    # re.compile関数を呼び出し、Regaxオブジェクトを作成
    phone_num_regex = re.compile(regex_text)

    # # Regaxオブジェクトのメソッド(search)に検索対象の文字列を渡しえt、Matchオブジェクトを作成
    mo = phone_num_regex.search(text)

    # 1つの電話番号を返す
    if mo != None:
        print('電話が見つかりました: ' + mo.group())
    else:
        print('電話番号が見つかりませんでした')

    # # 複数の電話番号を返す
    # mo2 = phone_num_regex.findall(text)
    # for i in range(len(mo2)):
    #     print('電話が見つかりました: ' + mo2[i])
    



# テストコード
if __name__ == "__main__":
    phone_number = '私の電話番号は080-1234-1234だよ、090-8981-0983'
    regax = r"\d{3}-\d{4}-\d{4}" 
    basic_is_phone_number(phone_number, regax)
